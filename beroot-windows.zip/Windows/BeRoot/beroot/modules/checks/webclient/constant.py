# -*- coding: utf-8 -*-


class constants(object):
    output_cmd = False
    is_running = False
    authentication_succeed = None
    smb_client = None
